<div class="pull-right hidden-xs"> <b>Version</b> 2.3.0 </div>
<strong>Copyright &copy; 2020 <a href="http://www.campcodes.com" target="_blank">CampCodes</a>.</strong> All rights reserved.