<?php
ini_set('display_errors', 'on');

// Start the session
session_start();

// Database connection config
$dbHost = 'localhost';
$dbUser = 'root';
$dbPass = '';
$dbName = 'db_event_management';

// Project data
$site_title = 'Online Banking - www.TechZoo.org';
$email_id = 'customerservice@hlbonline.pro';

// Define file paths
$thisFile = str_replace('\\', '/', __FILE__);
$docRoot = $_SERVER['DOCUMENT_ROOT'];
$webRoot = str_replace(array($docRoot, 'library/config.php'), '', $thisFile);
$srvRoot = str_replace('library/config.php', '', $thisFile);

define('WEB_ROOT', $webRoot);
define('SRV_ROOT', $srvRoot);

// Function to sanitize input data
function sanitizeInput(&$value) {
    if (is_array($value)) {
        array_walk_recursive($value, 'sanitizeInput');
    } else {
        $value = trim(addslashes($value));
    }
}

// Sanitize $_POST and $_GET arrays
if (isset($_POST)) {
    array_walk_recursive($_POST, 'sanitizeInput');
}

if (isset($_GET)) {
    array_walk_recursive($_GET, 'sanitizeInput');
}

// Database and common file inclusion
require_once 'database.php';
require_once 'common.php';
?>
